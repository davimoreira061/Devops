# Meu Projeto Git
Projeto introdutório para praticar versionamento com Git e GitHub Flow.

## Arquivos
- README.md
- index.html
- style.css
- script.js

## Próximo passo
Entender a diferença entre modified e
untracked.## Fluxo de trabalho
Este projeto utiliza GitHub Flow.
